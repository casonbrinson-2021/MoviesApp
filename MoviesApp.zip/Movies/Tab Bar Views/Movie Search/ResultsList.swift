//
//  ResultsList.swift
//  Movies
//
//  Created by Gregory Cason Brinson on 11/14/20.
//  Copyright © 2020 Gregory Cason Brinson. All rights reserved.
//

import SwiftUI

struct ResultsList: View {
    var body: some View {
            List {
                ForEach(searchedMoviesFound) { aMovie in
                    NavigationLink(destination: ResultDetails(movie: aMovie)) {
                        ResultItem(movie: aMovie)
                    }
                }
            }
            .navigationBarTitle(Text("Found Movies"), displayMode: .inline)
    }
}

struct ResultsList_Previews: PreviewProvider {
    static var previews: some View {
        ResultsList()
    }
}
