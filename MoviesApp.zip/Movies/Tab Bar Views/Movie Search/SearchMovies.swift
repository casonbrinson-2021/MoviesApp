//
//  SearchMovies.swift
//  Movies
//
//  Created by Gregory Cason Brinson on 11/14/20.
//  Copyright © 2020 Gregory Cason Brinson. All rights reserved.
//

import SwiftUI

struct SearchMovies: View {
    
    @State private var searchFieldValue = ""
    @State private var showMissingInputDataAlert = false
    @State private var searchCompleted = false
    
    var body: some View {
        NavigationView {
            ZStack {
                Color.gray.opacity(0.1).edgesIgnoringSafeArea(.all)
                
                Form {
                    Section(header: Text("Enter Movie Title To Search")) {
                        HStack {
                            TextField("Enter Search Query", text: $searchFieldValue)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .disableAutocorrection(true)
                        
                            // Button to clear the text field
                            Button(action: {
                                self.searchFieldValue = ""
                                self.showMissingInputDataAlert = false
                                self.searchCompleted = false
                            }) {
                                Image(systemName: "clear")
                                    .imageScale(.medium)
                                    .font(Font.title.weight(.regular))
                            }//end of button
                        }   // End of HStack
                    }//end of Section 1
                    Section(header: Text("Search Movies")) {
                        HStack {
                            Button(action: {
                                if self.inputDataValidated() {
                                    self.searchApi()
                                    print("Finished search api")
                                    self.searchCompleted = true
                                } else {
                                    self.showMissingInputDataAlert = true
                                }
                            }) {
                                Text(self.searchCompleted ? "Search Completed" : "Search")
                            }
                            .frame(width: 240, height: 36, alignment: .center)
                            .background(
                                RoundedRectangle(cornerRadius: 16)
                                    .strokeBorder(Color.black, lineWidth: 1)
                            )
                        }   // End of HStack
                    }//end of Section 2
                    
                    if searchCompleted {
                        Section(header: Text("List Movies Found")) {
                            NavigationLink(destination: showSearchResults) {
                                HStack {
                                    Image(systemName: "list.bullet")
                                        .imageScale(.medium)
                                        .font(Font.title.weight(.regular))
                                        .foregroundColor(.blue)
                                    Text("List Movies Found")
                                        .font(.system(size: 16))
                                }//end of HStack
                            }//end of Navigation View
                            .frame(minWidth: 300, maxWidth: 500)
                        }//end of Section 3
                    }//end of if statement
                    
                }//end of Form
                .navigationBarTitle(Text("Search Movies"), displayMode: .inline)
                .alert(isPresented: $showMissingInputDataAlert, content: { self.missingInputDataAlert })
                .padding(.top, 100)
            }//end of ZStack
        }//end of Navigation View
    }
    
    
    func searchApi() {
        let queryTrimmed = self.searchFieldValue.trimmingCharacters(in: .whitespacesAndNewlines)
        print(queryTrimmed)
        // Public function obtainCountryDataFromApi is given in CountryApiData.swift
        obtainSearchDataFromApi(movieName: queryTrimmed)
    }
    
    var showSearchResults: some View {
        if searchedMoviesFound.isEmpty {
            return AnyView(notFoundMessage)
        }
        return AnyView(ResultsList())
    }
    
    var notFoundMessage: some View {
        VStack {
            Image(systemName: "exclamationmark.triangle")
                .imageScale(.large)
                .font(Font.title.weight(.medium))
                .foregroundColor(.red)
                .padding()

            Text("No Movie Found!\n\nThe entered query Invalid Name did not return any movie from the API! Please enter another search query.")
                .fixedSize(horizontal: false, vertical: true)
                .multilineTextAlignment(.center)
                .padding()
        }
        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        .background(Color(red: 1.0, green: 1.0, blue: 240/255))     // Ivory color
    }
    
    var missingInputDataAlert: Alert {
        Alert(title: Text("Movie Search Field is Empty!"),
              message: Text("Please enter a search query!"),
              dismissButton: .default(Text("OK")) )
    }
    
    func inputDataValidated() -> Bool {
        // Remove spaces, if any, at the beginning and at the end of the entered search query string
        let queryTrimmed = self.searchFieldValue.trimmingCharacters(in: .whitespacesAndNewlines)

        if queryTrimmed.isEmpty {
            return false
        }
        return true
    }
}

struct SearchMovies_Previews: PreviewProvider {
    static var previews: some View {
        SearchMovies()
    }
}
