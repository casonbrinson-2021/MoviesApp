//
//  GenreList.swift
//  Movies
//
//  Created by Gregory Cason Brinson on 11/14/20.
//  Copyright © 2020 Gregory Cason Brinson. All rights reserved.
//

import SwiftUI

struct GenreList: View {
    
    @EnvironmentObject var userData: UserData
    
    let movieGenresList = ["Action", "Adventure", "Animation", "Biography", "Comedy", "Crime", "Documentary", "Drama", "Family", "Fantasy", "Horror", "Music", "Mystery", "Romance", "Sci-Fi", "Suspense", "Thriller", "War", "Western"]
    
    //initial value of Action since that is the first option in the genres list
    @State private var searchItem = "Action"
    
    @State private var selectedIndex = 0
    
    var body: some View {
        NavigationView {
            List {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack {
                        ForEach(0..<movieGenresList.count, id: \.self) { index in
                            //need to make this an vstack with the text under it
                            Button(action: {
                                self.selectedIndex = index
                                self.searchItem = movieGenresList[self.selectedIndex]
                            }) {
                                VStack {
                                    Image(movieGenresList[index])
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .frame(width: 50)
                                    if(self.selectedIndex == index) {
                                    Text(movieGenresList[index])
                                        .font(.system(size: 14))
                                        .foregroundColor(.red)
                                    }
                                    else {
                                        Text(movieGenresList[index])
                                            .font(.system(size: 14))
                                            .foregroundColor(.blue)
                                    }
                                }
                            }//end of Button thing
                        }
                    }//end of HStack
                }//end of Scroll view
                ForEach(userData.searchableOrderedMoviesList.filter {self.searchItem.isEmpty ? true : $0.localizedStandardContains(self.searchItem)}, id: \.self)
                { item in
                    NavigationLink(destination: GenreDetails(movie: self.searchItemMovie(searchListItem: item)))
                    {
                        GenreItem(movie: self.searchItemMovie(searchListItem: item))
                    }
                }
                
            }//end of List
            .navigationBarTitle(Text("Genre List of Movies"), displayMode: .inline)
        }
    }//end of body
    
    func searchItemMovie(searchListItem: String) -> Movie {
        // Find the index number of countriesList matching the country attribute 'id'
        let index = userData.moviesList.firstIndex(where: {$0.id.uuidString == searchListItem.components(separatedBy: "|")[0]})!

        return userData.moviesList[index]
    }
    
}//end of struct

struct GenreList_Previews: PreviewProvider {
    static var previews: some View {
        GenreList()
    }
}
