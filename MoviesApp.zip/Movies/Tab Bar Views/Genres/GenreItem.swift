//
//  GenreItem.swift
//  Movies
//
//  Created by Gregory Cason Brinson on 11/14/20.
//  Copyright © 2020 Gregory Cason Brinson. All rights reserved.
//

import SwiftUI

struct GenreItem: View {
    
    let movie: Movie
    
    var body: some View {
        HStack {
            
            getImageFromUrl(url: "https://image.tmdb.org/t/p/w500/\(movie.posterFileName)", defaultFilename: "ImageUnavailable")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 80)
            VStack(alignment: .leading) {
                Text(movie.title)
                HStack{
                    Image("IMDb")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 20)
                    Text(movie.imdbRating)
                }
                Text(movie.actors)
                    .fixedSize(horizontal: false, vertical: true)
                    .multilineTextAlignment(.leading)
                HStack {
                    Text(movie.mpaaRating)
                    Text("\(movie.runtime) mins")
                    Text(movie.releaseDate)
                }
            }//end of VStack
        }//end of HStack
        .font(.system(size: 14))
    }
}

struct GenreItem_Previews: PreviewProvider {
    static var previews: some View {
        //GenreItem()
        Text("Hello World")
    }
}
