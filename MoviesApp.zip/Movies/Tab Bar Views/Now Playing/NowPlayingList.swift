//
//  NowPlayingList.swift
//  Movies
//
//  Created by Gregory Cason Brinson on 11/14/20.
//  Copyright © 2020 Gregory Cason Brinson. All rights reserved.
//

import SwiftUI

struct NowPlayingList: View {
    var body: some View {
        NavigationView {
            List {
                ForEach(nowPlayingFound) { aMovie in
                    NavigationLink(destination: NowPlayingDetails(movie: aMovie)) {
                        NowPlayingItem(movie: aMovie)
                    }
                }
            }
            .navigationBarTitle(Text("Movies Now Playing in Theaters"), displayMode: .inline)
        }
        .customNavigationViewStyle()
        
    }//end of body
}//end of struct

struct NowPlayingList_Previews: PreviewProvider {
    static var previews: some View {
        NowPlayingList()
    }
}
