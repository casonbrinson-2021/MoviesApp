//
//  NowPlayingDetails.swift
//  Movies
//
//  Created by Gregory Cason Brinson on 11/14/20.
//  Copyright © 2020 Gregory Cason Brinson. All rights reserved.
//

import SwiftUI

struct NowPlayingDetails: View {
    
    @EnvironmentObject var userData: UserData
    
    @State private var showAlert = false
    
    let movie: Movie
    
    var body: some View {
        Form {
            Group {
                Section(header: Text("Movie Title")) {
                    Text(movie.title)
                }//end of Section 1
                Section(header: Text("Movie Poster")) {
                    getImageFromUrl(url: "https://image.tmdb.org/t/p/w500/\(movie.posterFileName)", defaultFilename: "ImageUnavailable")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                }//end of Section 2
                Section(header: Text("YouTube Movie Trailer")) {
                    NavigationLink(destination:
                        WebView(url: "https://www.youtube.com/embed/\(movie.youTubeTrailerId)")
                            .navigationBarTitle(Text("Play Movie Trailer"), displayMode: .inline)) {
                            HStack {
                                Image(systemName: "play.rectangle.fill")
                                    .imageScale(.medium)
                                    .font(Font.title.weight(.regular))
                                    .foregroundColor(.red)
                                Text("Play YouTube Movie Trailer")
                                    .font(.system(size: 14))
                            }//end of HStack
                            .frame(minWidth: 300, maxWidth: 500, alignment: .leading)
                    }//end of NavigationLink
                }//end of Section 3
                Section(header: Text("Movie Overview")) {
                    Text(movie.overview)
                }//end of Section 4
                Section(header: Text("List Movie Cast Members")) {
                    NavigationLink(destination: showCastMemebers) {
                        HStack {
                            Image(systemName: "rectangle.stack.person.crop")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                                .foregroundColor(.blue)
                            Text("List Movie Cast Members")
                                .font(.system(size:14))
                        }
                    }
                }//end of Section 5
                Section(header: Text("Add this movie to Favorites List")) {
                    HStack{
                        Button(action: {
                            userData.moviesList.append(movie)
                            
                            userData.searchableOrderedMoviesList.append("\(movie.id)|\(movie.title)|\(movie.overview)|\(movie.genres)|\(movie.releaseDate)|\(movie.director)|\(movie.actors)|\(movie.mpaaRating)")
                            
                            movieStructList = userData.moviesList
                            
                            orderedSearchableMoviesList = userData.searchableOrderedMoviesList
                            self.showAlert = true
                        }) {
                            HStack {
                                Image(systemName: "plus")
                                    .imageScale(.medium)
                                    .font(Font.title.weight(.regular))
                                    .foregroundColor(.blue)
                                Text("Add Movie to Favorites")
                                    .font(.system(size:14))
                                    .foregroundColor(.blue)
                            }
                        }
                        
                    }//end of HStack
                }//end of Section 6
                Section(header: Text("Movie Runtime")) {
                    Text(minToHoursAndMins(mins: movie.runtime))
                }//end of section 7
                Section(header: Text("Movie Genres")) {
                    Text(movie.genres)
                }//end of section 8
                Section(header: Text("Movie Release Date")) {
                    Text(movie.releaseDate)
                }//end of section 9
                Section(header: Text("Movie Director")) {
                    Text(movie.director)
                }//end of section 10
            }//end og Group 1
            Group {
                Section(header: Text("Movie Top Actors")) {
                    Text(movie.actors)
                }//end of section 1
                Section(header: Text("Movie MPAA Rating")) {
                    Text(movie.mpaaRating)
                }//end of section 2
                Section(header: Text("Movie IMDB Rating")) {
                    Text(movie.imdbRating)
                }//end of section 3
            }//end of Group 2
            
        }//end of Form
        .alert(isPresented: $showAlert, content: { self.addedAlert })
        .navigationBarTitle(Text(movie.title), displayMode: .inline)
        .font(.system(size: 14))
    }//end of body
    
    var showCastMemebers: some View {
        obtainCastMemberDataFromApi(movieName: movie.title)
        
        return AnyView(CastList())
    }
    
    var addedAlert: Alert {
        Alert(title: Text("Movie Added!"),
              message: Text("This movie is added to Favorites list."),
              dismissButton: .default(Text("OK")) )
    }
}

struct NowPlayingDetails_Previews: PreviewProvider {
    static var previews: some View {
        //NowPlayingDetails()
        Text("Hello World")
    }
}
