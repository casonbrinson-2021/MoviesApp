//
//  CastList.swift
//  Movies
//
//  Created by Gregory Cason Brinson on 11/11/20.
//  Copyright © 2020 Gregory Cason Brinson. All rights reserved.
//

import SwiftUI

struct CastList: View {
    
    var body: some View {
        List {
            ForEach(castMembersFound) { aCastMember in
                CastItem(castMember: aCastMember)
            }
        }
    }
}

struct CastList_Previews: PreviewProvider {
    static var previews: some View {
        CastList()
    }
}
