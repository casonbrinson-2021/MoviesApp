//
//  FavoriteItem.swift
//  Movies
//
//  Created by Gregory Cason Brinson on 11/11/20.
//  Copyright © 2020 Gregory Cason Brinson. All rights reserved.
//

import SwiftUI

struct FavoriteItem: View {
    
    let movie: Movie
    
    var body: some View {
        HStack {
            
            getImageFromUrl(url: "https://image.tmdb.org/t/p/w500/\(movie.posterFileName)", defaultFilename: "ImageUnavailable")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 80)
            VStack(alignment: .leading) {
                Text(movie.title)
                HStack{
                    Image("IMDb")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 20)
                    Text(movie.imdbRating)
                }
                Text(movie.actors)
                    .fixedSize(horizontal: false, vertical: true)
                    .multilineTextAlignment(.leading)
                HStack {
                    Text(movie.mpaaRating)
                    Text("\(movie.runtime) mins")
                    Text(movie.releaseDate)
                }
            }//end of VStack
        }//end of HStack
        .font(.system(size: 14))
        
    }//end of Body
}//end of struct

struct FavoriteItem_Previews: PreviewProvider {
    static var previews: some View {
        FavoriteItem(movie: movieStructList[0])
    }
}
