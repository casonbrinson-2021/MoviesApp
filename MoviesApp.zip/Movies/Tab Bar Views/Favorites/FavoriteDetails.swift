//
//  FavoriteDetails.swift
//  Movies
//
//  Created by Gregory Cason Brinson on 11/11/20.
//  Copyright © 2020 Gregory Cason Brinson. All rights reserved.
//

import SwiftUI

struct FavoriteDetails: View {
    
    let movie: Movie
    
    var body: some View {
        Form {
            Group {
                Section(header: Text("Movie Title")) {
                    Text(movie.title)
                }//end of Section 1
                Section(header: Text("Movie Poster")) {
                    getImageFromUrl(url: "https://image.tmdb.org/t/p/w500/\(movie.posterFileName)", defaultFilename: "ImageUnavailable")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                }//end of Section 2
                Section(header: Text("YouTube Movie Trailer")) {
                    NavigationLink(destination:
                        WebView(url: "https://www.youtube.com/embed/\(movie.youTubeTrailerId)")
                            .navigationBarTitle(Text("Play Movie Trailer"), displayMode: .inline)) {
                            HStack {
                                Image(systemName: "play.rectangle.fill")
                                    .imageScale(.medium)
                                    .font(Font.title.weight(.regular))
                                    .foregroundColor(.red)
                                Text("Play YouTube Movie Trailer")
                                    .font(.system(size: 14))
                            }//end of HStack
                            .frame(minWidth: 300, maxWidth: 500, alignment: .leading)
                    }//end of NavigationLink
                }//end of Section 3
                Section(header: Text("Movie Overview")) {
                    Text(movie.overview)
                }//end of Section 4
                Section(header: Text("List Movie Cast Members")) {
                    NavigationLink(destination: showCastMemebers) {
                        HStack {
                            Image(systemName: "rectangle.stack.person.crop")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                                .foregroundColor(.blue)
                            Text("List Movie Cast Members")
                                .font(.system(size:14))
                        }
                        //obtainCastMemberDataFromApi(movieName: movie.title)
                    }
                }//end of Section 5
                Section(header: Text("Movie Runtime")) {
                    Text(minToHoursAndMins(mins: movie.runtime))
                }//end of section 6
                Section(header: Text("Movie Genres")) {
                    Text(movie.genres)
                }//end of section 7
                Section(header: Text("Movie Release Date")) {
                    Text(movie.releaseDate)
                }//end of section 8
                Section(header: Text("Movie Director")) {
                    Text(movie.director)
                }//end of section 9
                Section(header: Text("Movie Top Actors")) {
                    Text(movie.actors)
                }//end of section 10
            }//end og Group 1
            Group {
                Section(header: Text("Movie MPAA Rating")) {
                    Text(movie.mpaaRating)
                }//end of section 11
                Section(header: Text("Movie IMDB Rating")) {
                    Text(movie.imdbRating)
                }//end of section 10
            }//end of Group 2
            
        }//end of Form
        .navigationBarTitle(Text(movie.title), displayMode: .inline)
        .font(.system(size: 14))
    }//end of body
    
    var showCastMemebers: some View {
        obtainCastMemberDataFromApi(movieName: movie.title)
        
        return AnyView(CastList())
    }
    
    
}//end of struct

struct FavoriteDetails_Previews: PreviewProvider {
    static var previews: some View {
        FavoriteDetails(movie: movieStructList[0])
    }
}
