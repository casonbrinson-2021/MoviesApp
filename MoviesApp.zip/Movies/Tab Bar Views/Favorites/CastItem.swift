//
//  CastItem.swift
//  Movies
//
//  Created by Gregory Cason Brinson on 11/11/20.
//  Copyright © 2020 Gregory Cason Brinson. All rights reserved.
//

import SwiftUI

struct CastItem: View {
    
    let castMember: CastMember
    
    var body: some View {
        HStack {
            getImageFromUrl(url: "https://image.tmdb.org/t/p/w500/\(castMember.photoFileName)", defaultFilename: "ImageUnavailable")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 80)
            VStack(alignment: .leading) {
                Text(castMember.name)
                Text("playing")
                Text(castMember.character)
            }
        }
        .font(.system(size: 14))
    }
}

struct CastItem_Previews: PreviewProvider {
    static var previews: some View {
        //CastItem()
        Text("hello world")
    }
}
