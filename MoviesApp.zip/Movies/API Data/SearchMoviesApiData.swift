//
//  SearchMoviesApiData.swift
//  Movies
//
//  Created by Gregory Cason Brinson on 11/14/20.
//  Copyright © 2020 Gregory Cason Brinson. All rights reserved.
//

import SwiftUI
import Foundation

var searchedMoviesFound = [Movie]()


public func obtainSearchDataFromApi(movieName: String) {
    searchedMoviesFound.removeAll()
    
    //**********************************************
    //first part of the function to get the movie id
    let searchQuery = movieName.replacingOccurrences(of: " ", with: "+")
    
    var apiUrl = "https://api.themoviedb.org/3/search/movie?api_key=\(apiKey)&query=\(searchQuery)"
    
    var jsonDataFromApi = getJsonDataFromApi(apiUrl: apiUrl)
    
    var dataDictionary = Dictionary<String, Any>()
    
    do {
        let jsonResponse = try JSONSerialization.jsonObject(with: jsonDataFromApi!, options: JSONSerialization.ReadingOptions.mutableContainers)
        
        if let jsonObject = jsonResponse as? [String: Any] {
            dataDictionary = jsonObject
        } else {return}
    }
    catch {
        print("Returning in the catch")
        return
    }
    
    //need to set all of these
    var id: UUID
    var title = ""
    var posterFilename = ""
    var overview = ""
    var genres = ""
    var releaseDate = ""
    var runtime = 0
    var director = ""
    var actors = ""
    var mpaaRating = ""
    var imdbRating = ""
    var youTubeTrailerId = ""
    var tmdbID = 0
    
    
    var resultsDataDictionary = Dictionary<String, Any>()
    var movieId: Int
    var imdbId = ""
    

    if let jsonArray = dataDictionary["results"] as? [Any] {
        for aJsonObject in jsonArray {
            if let jsonObject = aJsonObject as? [String: Any] {
                resultsDataDictionary = jsonObject
            } else {return}
            //set some stuff here
            title = resultsDataDictionary["title"] as! String
            
            if let posterPath = resultsDataDictionary["poster_path"] as? String {
                posterFilename = String(posterPath.dropFirst(1))
            }
            //posterFilename = String(posterPath.dropFirst(1))
            
            if let temp = resultsDataDictionary["overview"] as? String {
                overview = temp
            }
            //overview = resultsDataDictionary["overview"] as! String
            
            if let temp = resultsDataDictionary["release_date"] as? String {
                releaseDate = temp
            }
            //releaseDate = resultsDataDictionary["release_date"] as! String
            
            movieId = resultsDataDictionary["id"] as! Int
            tmdbID = movieId
            
            
            //get the next url's json data for the rest of the information
            apiUrl = "https://api.themoviedb.org/3/movie/\(movieId)?api_key=\(apiKey)&append_to_response=videos"
            jsonDataFromApi = getJsonDataFromApi(apiUrl: apiUrl)
            do {
                let jsonResponse = try JSONSerialization.jsonObject(with: jsonDataFromApi!, options: JSONSerialization.ReadingOptions.mutableContainers)
                
                if let jsonObject = jsonResponse as? [String: Any] {
                    dataDictionary = jsonObject
                } else {return}
            }
            catch {
                print("Returning in the catch")
                return
            }
            if let temp = dataDictionary["imdb_id"] as? String {
                imdbId = temp
            }
            //imdbId = dataDictionary["imdb_id"] as! String
            if let checkRuntime = dataDictionary["runtime"] as? Int {
                runtime = checkRuntime
            } else {
                runtime = 0
            }
            //runtime = dataDictionary["runtime"] as! Int
            
            var videoDataDictionary = Dictionary<String, Any>()
            
            if let anotherJsonObject = dataDictionary["videos"] as? [String: Any] {
                resultsDataDictionary = anotherJsonObject
                if let anotherJsonArray = resultsDataDictionary["results"] as? [Any] {
                    if(!anotherJsonArray.isEmpty) {
                        if let newJsonObject = anotherJsonArray[0] as? [String: Any] {
                            videoDataDictionary = newJsonObject
                            youTubeTrailerId = videoDataDictionary["key"] as! String
                        } else {return}
                    }
                } else {return}
            } else {return}
            
            
            
            //getting final items needed from the last url
            apiUrl = "https://www.omdbapi.com/?apikey=9f67dd7a&i=\(imdbId)&plot=full&r=json"
            jsonDataFromApi = getJsonDataFromApi(apiUrl: apiUrl)
            do {
                let jsonResponse = try JSONSerialization.jsonObject(with: jsonDataFromApi!, options: JSONSerialization.ReadingOptions.mutableContainers)
                
                if let jsonObject = jsonResponse as? [String: Any] {
                    dataDictionary = jsonObject
                } else {return}
            }
            catch {
                print("Returning in the catch")
                return
            }
            if let temp = dataDictionary["Rated"] as? String {
                mpaaRating = temp
            }
            //mpaaRating = dataDictionary["Rated"] as! String
            if let temp = dataDictionary["Genre"] as? String {
                genres = temp
            }
            //genres = dataDictionary["Genre"] as! String
            if let temp = dataDictionary["Director"] as? String {
                director = temp
            }
            //director = dataDictionary["Director"] as! String
            if let temp = dataDictionary["Actors"] as? String {
                actors = temp
            }
            //actors = dataDictionary["Actors"] as! String
            if let temp = dataDictionary["imdbRating"] as? String {
                imdbRating = temp
            }
            //imdbRating = dataDictionary["imdbRating"] as! String
            
            
            //add the new movie to the found NowPlaying list
            id = UUID()
            searchedMoviesFound.append(Movie(id: id, title: title, posterFileName: posterFilename, overview: overview, genres: genres, releaseDate: releaseDate, runtime: runtime, director: director, actors: actors, mpaaRating: mpaaRating, imdbRating: imdbRating, youTubeTrailerId: youTubeTrailerId, tmdbID: tmdbID))
            
        }//end of for loop
    } else {return}
    //**********************************************
}
