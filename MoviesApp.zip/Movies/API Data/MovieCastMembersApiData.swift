//
//  MovieCastMembersApiData.swift
//  Movies
//
//  Created by Gregory Cason Brinson on 11/11/20.
//  Copyright © 2020 Gregory Cason Brinson. All rights reserved.
//

import SwiftUI
import Foundation

var castMembersFound = [CastMember]()
var apiKey = "7a64909754593730156ad5e8dba115c9"

public func obtainCastMemberDataFromApi(movieName: String) {
    
    castMembersFound.removeAll()
    
    //**********************************************
    //first part of the function to get the movie id
    let searchQuery = movieName.replacingOccurrences(of: " ", with: "+")
    
    var apiUrl = "https://api.themoviedb.org/3/search/movie?api_key=\(apiKey)&query=\(searchQuery)"
    
    var jsonDataFromApi = getJsonDataFromApi(apiUrl: apiUrl)
    
    var dataDictionary = Dictionary<String, Any>()
    
    do {
        let jsonResponse = try JSONSerialization.jsonObject(with: jsonDataFromApi!, options: JSONSerialization.ReadingOptions.mutableContainers)
        
        if let jsonObject = jsonResponse as? [String: Any] {
            dataDictionary = jsonObject
        } else {return}
    }
    catch {
        print("Returning in the catch")
        return
    }
    
    
    var resultsDataDictionary = Dictionary<String, Any>()
    var id: Int
    
    if let jsonArray = dataDictionary["results"] as? [Any] {
        if let jsonObject = jsonArray[0] as? [String: Any] {
            resultsDataDictionary = jsonObject
        } else {return}
        
        id = resultsDataDictionary["id"] as! Int
    } else {return}
    //**********************************************
    
    
    //**********************************************
    //second part of the function to actually get cast information
    apiUrl = "https://api.themoviedb.org/3/movie/\(id)?api_key=\(apiKey)&append_to_response=credits"
    
    jsonDataFromApi = getJsonDataFromApi(apiUrl: apiUrl)
    
    do {
        let jsonResponse = try JSONSerialization.jsonObject(with: jsonDataFromApi!, options: JSONSerialization.ReadingOptions.mutableContainers)
        
        if let jsonObject = jsonResponse as? [String: Any] {
            dataDictionary = jsonObject
        } else {return}
    }
    catch {
        print("Returning in the catch")
        return
    }
    
    var creditsDataDictionary = Dictionary<String, Any>()
    var castDataDictionary = Dictionary<String, Any>()
    
    var name = ""
    var character = ""
    //var posterPath = ""
    var photoFileName = ""
    
    if let jsonObject = dataDictionary["credits"] as? [String: Any] {
        creditsDataDictionary = jsonObject
        if let jsonArray = creditsDataDictionary["cast"] as? [Any] {
            for aJsonObject in jsonArray {
                if let anotherJsonObject = aJsonObject as? [String: Any] {
                    castDataDictionary = anotherJsonObject
                }
                
                name = castDataDictionary["name"] as! String
                character = castDataDictionary["character"] as! String
                //posterPath = castDataDictionary["profile_path"] as! String
                //photoFileName = String(posterPath.dropFirst(1))
                if let posterPath = castDataDictionary["profile_path"] as? String {
                    photoFileName = String(posterPath.dropFirst(1))
                } else {
                    photoFileName = "ImageUnavailable"
                }
                let theId = UUID()
                
                //add the cast member to the array
                castMembersFound.append(CastMember(id: theId, photoFileName: photoFileName, name: name, character: character))
                
                //checking to make sure its going throught them all
                print("added one")
                
            }//end of for loop
        }
    }
    
    
    
}
