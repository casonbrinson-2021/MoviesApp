//
//  NowPlayingApiData.swift
//  Movies
//
//  Created by Gregory Cason Brinson on 11/14/20.
//  Copyright © 2020 Gregory Cason Brinson. All rights reserved.
//

import SwiftUI
import Foundation

var nowPlayingFound = [Movie]()

public func obtainNowPlayingDataFromApi() {
    
    nowPlayingFound.removeAll()
    
    var apiUrl = "https://api.themoviedb.org/3/movie/now_playing?api_key=\(apiKey)"
    
    var jsonDataFromApi = getJsonDataFromApi(apiUrl: apiUrl)
    
    var dataDictionary = Dictionary<String, Any>()
    
    do {
        let jsonResponse = try JSONSerialization.jsonObject(with: jsonDataFromApi!, options: JSONSerialization.ReadingOptions.mutableContainers)
        
        if let jsonObject = jsonResponse as? [String: Any] {
            dataDictionary = jsonObject
        } else {return}
    }
    catch {
        print("Returning in the catch")
        return
    }
    
    //need to set all of these
    var id: UUID
    var title = ""
    var posterFilename = ""
    var overview = ""
    var genres = ""
    var releaseDate = ""
    var runtime = 0
    var director = ""
    var actors = ""
    var mpaaRating = ""
    var imdbRating = ""
    var youTubeTrailerId = ""
    var tmdbID = 0

    var resultsDataDictionary = Dictionary<String, Any>()
    var movieId: Int
    var imdbId = ""
    
    if let jsonArray = dataDictionary["results"] as? [Any] {
        for aJsonObject in jsonArray {
            if let jsonObject = aJsonObject as? [String: Any] {
                resultsDataDictionary = jsonObject
            } else {return}
            //set some stuff here
            title = resultsDataDictionary["title"] as! String
            
            let posterPath = resultsDataDictionary["poster_path"] as! String
            posterFilename = String(posterPath.dropFirst(1))
            
            overview = resultsDataDictionary["overview"] as! String
            releaseDate = resultsDataDictionary["release_date"] as! String
            
            movieId = resultsDataDictionary["id"] as! Int
            tmdbID = movieId
            
            
            //get the next url's json data for the rest of the information
            apiUrl = "https://api.themoviedb.org/3/movie/\(movieId)?api_key=\(apiKey)&append_to_response=videos"
            jsonDataFromApi = getJsonDataFromApi(apiUrl: apiUrl)
            do {
                let jsonResponse = try JSONSerialization.jsonObject(with: jsonDataFromApi!, options: JSONSerialization.ReadingOptions.mutableContainers)
                
                if let jsonObject = jsonResponse as? [String: Any] {
                    dataDictionary = jsonObject
                } else {return}
            }
            catch {
                print("Returning in the catch")
                return
            }
            imdbId = dataDictionary["imdb_id"] as! String
            runtime = dataDictionary["runtime"] as! Int
            
            var videoDataDictionary = Dictionary<String, Any>()
            
            if let anotherJsonObject = dataDictionary["videos"] as? [String: Any] {
                resultsDataDictionary = anotherJsonObject
                if let anotherJsonArray = resultsDataDictionary["results"] as? [Any] {
                    if(!anotherJsonArray.isEmpty) {
                        if let newJsonObject = anotherJsonArray[0] as? [String: Any] {
                            videoDataDictionary = newJsonObject
                            youTubeTrailerId = videoDataDictionary["key"] as! String
                        } else {return}
                    }
                } else {return}
            } else {return}
                        
            
            //getting final items needed from the last url
            apiUrl = "https://www.omdbapi.com/?apikey=9f67dd7a&i=\(imdbId)&plot=full&r=json"
            jsonDataFromApi = getJsonDataFromApi(apiUrl: apiUrl)
            do {
                let jsonResponse = try JSONSerialization.jsonObject(with: jsonDataFromApi!, options: JSONSerialization.ReadingOptions.mutableContainers)
                
                if let jsonObject = jsonResponse as? [String: Any] {
                    dataDictionary = jsonObject
                } else {return}
            }
            catch {
                print("Returning in the catch")
                return
            }
            
            mpaaRating = dataDictionary["Rated"] as! String
            genres = dataDictionary["Genre"] as! String
            director = dataDictionary["Director"] as! String
            actors = dataDictionary["Actors"] as! String
            imdbRating = dataDictionary["imdbRating"] as! String
            
            
            //add the new movie to the found NowPlaying list
            id = UUID()
            nowPlayingFound.append(Movie(id: id, title: title, posterFileName: posterFilename, overview: overview, genres: genres, releaseDate: releaseDate, runtime: runtime, director: director, actors: actors, mpaaRating: mpaaRating, imdbRating: imdbRating, youTubeTrailerId: youTubeTrailerId, tmdbID: tmdbID))
            
        }//end of for loop
    } else {return}
    
    
    
    
    
    
    
    
}
