//
//  CastMemberStruct.swift
//  Movies
//
//  Created by Gregory Cason Brinson on 11/11/20.
//  Copyright © 2020 Gregory Cason Brinson. All rights reserved.
//

import SwiftUI

struct CastMember: Identifiable, Hashable, Codable {
    var id: UUID
    var photoFileName: String
    var name: String
    var character: String
}

