//
//  MoviesData.swift
//  Movies
//
//  Created by Gregory Cason Brinson on 11/11/20.
//  Copyright © 2020 Gregory Cason Brinson. All rights reserved.
//

import SwiftUI

//Global array of Cocktail structs
var movieStructList = [Movie]()

/*
 Each of orderedSearchableCocktailsList element contains the selected Cocktail attribute names seperated by vertical lines for use int he FavoritesList search
 */
var orderedSearchableMoviesList = [String]()


/*
 MARK: - Read Cocktails Data Files
 */
public func readMoviesDataFiles() {
    
    var documentDirectoryHasFiles = false
    let moviesDataFullFilename = "MoviesData.json"
    
    //Obtain URL of the CocktailsData.json file in document directory of the user's device
    //Global constant documentDirectory is defined in UtilityFunctions.swift
    let urlOfJsonFileInDocumentDirectory = documentDirectory.appendingPathComponent(moviesDataFullFilename)
    
    do {
        //try to get the contents of the file
        _=try Data(contentsOf: urlOfJsonFileInDocumentDirectory)
        
        //if try is succesful, then the CocktailsData.json file exists on the user's device
        //if try is unsuccesful then throws an exception
        documentDirectoryHasFiles = true
        
        movieStructList = decodeJsonFileIntoArrayOfStructs(fullFilename: moviesDataFullFilename, fileLocation: "Document Directory")
        print("MoviesData is loaded from document directory")
    } catch {
        documentDirectoryHasFiles = false
        
        //app is being launched for the first time
        movieStructList = decodeJsonFileIntoArrayOfStructs(fullFilename: moviesDataFullFilename, fileLocation: "Main Bundle")
        print("MoviesData is loaded from main bundle")
        
        
        for movie in  movieStructList {
            let selectedMovieAttributesForSearch = "\(movie.id)|\(movie.title)|\(movie.overview)|\(movie.genres)|\(movie.releaseDate)|\(movie.director)|\(movie.actors)|\(movie.mpaaRating)"
            
            orderedSearchableMoviesList.append(selectedMovieAttributesForSearch)
        }
    }//end of catch
    
    //read orderedSearchableCocktailsList file
    if documentDirectoryHasFiles {
        //get the URL of the file in the document directory of the user's device
        let urlOfFileInDocDir = documentDirectory.appendingPathComponent("OrderedSearchableMoviesList")
        
        let arrayFromFile: NSArray? = NSArray(contentsOf: urlOfFileInDocDir)
        
        if let arrayObtained = arrayFromFile {
            //store the unique id of the created array into the global variable
            orderedSearchableMoviesList = arrayObtained as! [String]
        } else {
            print("OrderedSearchableMoviesList file is not found in document directory on the user's device!")
        }
    }
}


/*
 MARK: - Write cocktails data files to document directory
 */
public func writeMoviesDataFiles() {
    //obtain URL of the JSON file into which data will be written
    let urlOfJsonFileInDocumentDirectory: URL? = documentDirectory.appendingPathComponent("MoviesData.json")
    
    //encode countryStructList into JSON file into which data will be written
    let encoder = JSONEncoder()
    if let encoded = try? encoder.encode(movieStructList) {
        do {
            try encoded.write(to: urlOfJsonFileInDocumentDirectory!)
        } catch {
            fatalError("Unable to write encoded movies data to document directory!")
        }
    } else {
        fatalError("Unable to encode movies data!")
    }
    
    //obtain URL of the file in the document directory on the user's device
    let urlOfFileInDocDirectory = documentDirectory.appendingPathComponent("OrderedSearchableMoviesList")
    
    (orderedSearchableMoviesList as NSArray).write(to: urlOfFileInDocDirectory, atomically: true)
}

