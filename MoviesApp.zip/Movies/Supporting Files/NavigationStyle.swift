//
//  NavigationStyle.swift
//  Movies
//
//  Created by Gregory Cason Brinson on 11/11/20.
//  Copyright © 2020 Gregory Cason Brinson. All rights reserved.
//

import SwiftUI

extension View {
    
    public func customNavigationViewStyle()->some View {
        //use single column navigation view for iphone
        if UIDevice.current.userInterfaceIdiom == .phone {
            return AnyView(self.navigationViewStyle(StackNavigationViewStyle()))
        } else {
            //use double column navigation for ipad
            return AnyView(self
                .navigationViewStyle(DoubleColumnNavigationViewStyle())
                .padding(.leading, 1))  //workaround to show master view until apple fixes the bug
        }
    }
}


