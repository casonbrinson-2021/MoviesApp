//
//  WebView.swift
//  Movies
//
//  Created by Gregory Cason Brinson on 11/11/20.
//  Copyright © 2020 Gregory Cason Brinson. All rights reserved.
//

import SwiftUI
import WebKit

struct WebView: UIViewRepresentable {
    // Input Parameter
    let url: String

    func makeUIView(context: Context) -> WKWebView  {
        WKWebView(frame: .zero)
    }

    // A WKWebView object displays interactive web content in a web browser within the app
    func updateUIView(_ webView: WKWebView, context: Context) {

        // Convert url from String type to URL struct type
        guard let urlStruct = URL(string: url) else {
            // Show nothing since url is invalid
            return
        }
        let urlLoadRequest = URLRequest(url: urlStruct)

        webView.allowsBackForwardNavigationGestures = true

        // Ask the webView object to display the web page for the given url
        webView.load(urlLoadRequest)
    }
}

 

struct WebView_Previews: PreviewProvider {
    static var previews: some View {
        WebView(url: "https://www.apple.com")
    }
}

 

